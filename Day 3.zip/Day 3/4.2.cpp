#include<iostream>
#include<cmath>
using namespace std;

class Frac{
	private:
		int tu,mau;
	public:
		Frac(){
			tu=mau=0;
		}
		Frac(int t,int m){
			tu=t;
			mau=m;
		}
		~Frac(){}
		void nhap();
		void xuat();
		bool operator>(Frac);
		Frac operator=(Frac);
};
int UCLN(int x,int y){
	int a=abs(x);
	int b=abs(y);
	while(a!=b){
		if(a>b)
			a=a-b;
		else 
			b=b-a;
	}	
	return a;
}
void Frac::nhap(){
	cout<<"Tu: ";cin>>tu;
	do{
		cout<<"Mau: ";cin>>mau;
	}while(mau==0);
	
}
void Frac::xuat(){
	int x=UCLN(tu,mau);
	tu/=x;
	mau/=x;
	if(mau==1){
		cout<<tu<<endl;
	}
	else if(mau==-1){
		tu=tu*(-1);
		cout<<tu<<endl;
	}
	else if(tu==0){
		cout<<tu<<endl;
	}
	else if(tu==mau){
		cout<<1<<endl;
	}
	else
		cout<<tu<<"/"<<mau<<endl;
}
bool Frac::operator>(Frac x){
	if(tu*x.mau>x.tu*mau)
		return true;
	return false;
}
Frac Frac::operator=(Frac x){
	tu=x.tu;
	mau=x.mau;
	return Frac(tu,mau);
}
template<typename T>
T max(T arr[]){
	T m=arr[0];
	for(int i=1;i<sizeof(arr)-1;i++){
		if(arr[i]>m)
			m=arr[i];
	}
	return m;
}
int main(){
	int n;
	cout<<"Nhap n=";
	cin>>n;
	Frac *f=new Frac[n];
	float *a=new float[n];
	cout<<"Nhap "<<n<<" phan so:"<<endl;
	for(int i=0;i<n;i++){
		(f+i)->nhap();
	}
	cout<<endl<<"-->Phan so max: ";
	max(f).xuat();
	cout<<"Nhap "<<n<<" so thuc:"<<endl;
	for(int i=0;i<n;i++){
		cin>>*(a+i);
	}
	cout<<endl<<"->>So thuc max: ";
	cout<<max(a);
}
