#include<iostream>
#include<cmath>
using namespace std;

class Frac{
	private:
		int tu,mau;
	public:
		Frac(){
			tu=mau=0;
		}
		Frac(int t,int m){
			tu=t;
			mau=m;
		}
		~Frac(){}
		void nhap();
		void xuat();
		Frac operator+(Frac);
		Frac operator=(Frac);
};
void Frac::nhap(){
	cout<<"Tu: ";cin>>tu;
	do{
		cout<<"Mau: ";cin>>mau;
	}while(mau==0);
	
}
int UCLN(int x,int y){
	int a=abs(x);
	int b=abs(y);
	while(a!=b){
		if(a>b)
			a=a-b;
		else 
			b=b-a;
	}	
	return a;
}
void Frac::xuat(){
	int x=UCLN(tu,mau);
	tu/=x;
	mau/=x;
	if(mau==1){
		cout<<tu<<endl;
	}
	else if(mau==-1){
		tu=tu*(-1);
		cout<<tu<<endl;
	}
	else if(tu==0){
		cout<<tu<<endl;
	}
	else if(tu==mau){
		cout<<1<<endl;
	}
	else
		cout<<tu<<"/"<<mau<<endl;
}
Frac Frac::operator+(Frac x){
	return Frac(tu*x.mau+x.tu*mau,x.mau*mau);
}
Frac Frac::operator=(Frac x){
	tu=x.tu;
	mau=x.mau;
	return Frac(tu,mau);
}
template<class T>
T sum(T *arr,int n){
	T s=arr[0];
	for(int i=1;i<n;i++){
		s=s+arr[i];
	}
	return s;
}
int main(){
	int n;
	cout<<"Nhap n=";
	cin>>n;
	Frac *f=new Frac[n];
	int *a=new int[n];
	cout<<"Nhap "<<n<<" phan so:"<<endl;
	for(int i=0;i<n;i++){
		(f+i)->nhap();
	}
	cout<<endl<<"-->Tong phan so: ";
	sum<Frac>(f,n).xuat();
	cout<<"Nhap "<<n<<" so thuc:"<<endl;
	for(int i=0;i<n;i++){
		cin>>*(a+i);
	}
	cout<<endl<<"->>Tong cac so nguyen: ";
	cout<<sum<int>(a,n);
}
