#include<iostream>
#include<string>
using namespace std;
template<typename T>
void max(T arr[]){
	int m=0;
	for(int i=1;i<sizeof(arr)-1;i++){
		if(arr[i]>arr[m])
			m=i;
	}
	cout<<"MAX: "<<arr[m];
}

int main(){
	string arr[3];
	for(int i=0;i<3;i++){
		cout<<"Xau "<<i<<": ";
		getline(cin,arr[i]);
	}
	max(arr);
}
